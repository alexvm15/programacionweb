/*

funciones

son fragmentos de codigo que escribimos para ejecutar una tarea y no volver a escribir el codigo mas de una vez 

-modularizamos el codigo
-es mas facil solventar errores
-deben realizar una sola tarea

esta es la sintaxis tradicional

fuction nombreFuction () {
// el codigo a ejecutar
};

esta es la forma con Es6

const nombreFuction= () =>{
// codigo a ejecutar
};

funciones pueden resivir parametros y van entre los parentesis

... (parametro1, parametro2) ....

estos parametros se usaran dentro de la funcion.

las funciones pueden devolver valores y se usa la palabra reservada 'return'

... {
    return parametro1 + parametro2
}

las funciones tiene que ser invocadas y las tenemos que llamar por fuera de la funcion 

nombreFuncion();

*/

//tradicional

function saludar () {
    console.log('hola mamá');
}

saludar();

//nueva forma

const despedida = () => {
    console.log("adios amigos");
}

despedida();

//funcion flecha con parametros

const mensajito = (dia) => {
    console.log(`hoy es ${dia}`);
}

mensajito('viernes nwn');
mensajito('lunes');
mensajito('martes');