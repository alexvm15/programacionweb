/*

clases

es una esctructura de Es6, que funciona como una plantilla o molde para crear objetos.

definimos una clase la palabra reservada class seguido de nombre de la clase

cuando creamos un objeto le llamamos instancera

para crear una clase necesitamos de una funcion constructora. se llama obligatoriamente constructory se ejecuta cada
vez que creamos un objeto

class Pokemon{
    constructor(nombre, tipo, poder)  {
                this.nombre = nombre

    }  
}

cuando definimos clases la primera letra de su nombre va en mayuscula

los paramteros van entre los parentecis y son las propiedades que van a tener los objetos
-para signar los parametros al objeto utilizamos la palabra reservada 'this' que hace referencia al objeto.
*/
class Pokemon {
     constructor (nombre, tipo, poder)


{

    this.nombre = nombre
    this.tipo = tipo
    this.poder = poder

}

pokedex(){
return `este es ${this.nombre} es un pokemon de tipo ${this.tipo} y su poder es de ${this.poder}`

}

}

const pikachu = new Pokemon ('pikachu','electrico', 1000);

const charmander = new Pokemon ('charmander','fuego', 900);

console.log(pikachu);
console.log(charmander);

console.log(pikachu.nombre);
console.log(charmander.tipo);

console.log(pikachu.pokedex());
console.log(charmander.pokedex());