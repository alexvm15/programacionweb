/*

eventos

cualquier cosa que puede suceder

el contenido se a leido 
el conteido se ha cargado 
el usuario mueva le raton 
el usuario  cierra la ventana 
es una muy larga de eventos
https://developer.mozilla.org/es/docs/Web/Events

sintaxis

element.addEventListener('event', callback) escuchador de events. que evento queremos ecuchar y
que va a ejecutar callback funcion que se dispara al ocurrir el evento

*/

/*
loclizamos los eventos con id

*/

const button = document.getElementById('button');
const box  = document.getElementById('box');
/*
eventos del raton 

click pulsar le boton izquierdo
dblclick pulsar dos veces seguidas el boton izquierdo
mouseenter entramos en la zona que tiene el moseenter salimos de la zona  que tiene el evento 
mousedown pulsamos el boton izquierdo en la zona del elemento 
mouseup cuando soltamos el boton izquierdo en la zona del evento.
mousemove movemos  el raton  en la zona del evento 

*/

//button.addEventListener('click' , () => console.log('pulsaste un click') );
//button.addEventListener('dblclick' , () => console.log('pulsaste doble click'));


//box.addEventListener('mouseenter', () => console.log('entraste'));
//box.addEventListener('mouseleave', () => console.log('saliste'));

//box.addEventListener('mousedown', () => console.log('picaste adentro'));
//box.addEventListener('mouseup', () => console.log('despegaste'));

//box.addEventListener('mousemove', () => console.log('te mueves'));

//input.addEventListener('keydown', () => console.log('pulsaste una tecla'));
//input.addEventListener('keypress', () => console.log('mantienes presionado'));
//input.addEventListener('keyup', () => console.log('soltaste una tecla'));


