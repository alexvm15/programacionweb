/*const titulo = document. getElementById("title");

console.log(titulo);


console.log(titulo.getAttribute("class"));


titulo.setAttribute("class", "big-title");
console.log(titulo);*/

titulo.classList("big-title" , "red-tile");
titulo.classList.remove("main-title", "red-tile");


console.log("titulo");
//console.log(titulo.classList.contains("main-title"));

//if (titulo.classList.contains("big-title")); {
//console.log("si lo tiene");
//}
 //else {
 //   console.log("estasperdido");
//}

titulo.classList.replace("big-title", "small-title");
console.log(titulo);