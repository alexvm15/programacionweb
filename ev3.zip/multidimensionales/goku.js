//definimos nuestro arreglo con dragon ball

var goku = [
    ['goku' ,         'sayayin' ,                 90000000000],  //indice0
    ['vegeta' ,       'sayayin' ,                  85000000000],  //indice 1
    ['wiz' ,           'angel' ,                    1000000000000],   //indice 2
    ['bills' ,   'dios de la destruccion' ,       100000000000],  //indice 3
       1                   
];

//creamos las variables que traeran el id de html

var miimagen = document.getElementById('imagen');
var minombre = document.getElementById('nombre');
var mitipo = document.getElementById('tipo');

//insertar texto dentro del elemento html

miimagen.innerText = 'imagen de goku: ' + goku[0][0];
minombre.innerHTML = 'nombre: ' + goku[0][0];
mitipo.innerText = 'tipo: ' + sayayin[0][1];

