//asi definimos un arreglo
var miarreglo = [1, 2, 3];
var otroArreglo = ["gato","perro","conejo"]

console.log(otroArreglo[1]) //perro

//definimos un arreglo anidado
var arregloAnidado = [[1,2,3],[4,5,6],[7,8,9]];
/*
arreglo     [[1,2,3] , [4,5,6] , [7,8,9]];
indice          0          1        2
sub indice    0 1 2    0 1 2      0 1 2  

*/

// asi llamamos a un dato de un arreglo multidimensional

console.log(arregloAnidado[2][1]);
console.log(arregloAnidado[0][2]);
console.log(arregloAnidado[1][1]);