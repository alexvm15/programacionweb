/*
ciclo while sirve para ejecutar codigo de forma ciclica mientra su condicion se cumpla 
*/

/* 
definimos la variable i
*/
/*
var i = 1;
var numero = prompt ("elige un numero")

while ( i <= numero){
    // equi va el codigo que se ejecuta.
    document.write("hola soy un cliclo bien perron <br>")
//sumamos una unidad a la variable i, para que la condicion deje de cumplirse
    //i = i + 1;
    i++;
}
*/

/*  
el ciclo do while ejecuta un codigo al menos una vez y si se cumple la condicion volvera a interarlo.

*/

var i = 0;
var numero = prompt ("elige un numero")

while ( i <= numero)
 do{
//aqui el codigo que se ejecuta en el ciclo.
document.write("Alex <br>");
i++;
 } while(i <10);
 